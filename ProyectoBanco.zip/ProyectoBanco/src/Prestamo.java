/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jonif
 */
public class Prestamo {
    //Se ingresan por la GUI
    private double montoPrestamo;
    private int tiempoPago;
    //Se presenta en la GUI
    private double montoPagar;
    private double interesAnual;
    private double cuotaMensual;

    @Override
    public String toString() {
        return "Detalles del Préstamo:\n" + "Monto del Préstamo: $" + montoPrestamo + "\nPlazo Permitido = " + tiempoPago + " meses\n Monto Final a Pagar: $" + montoPagar + "\nInterés Anual = " + interesAnual + "\nCuota Mensual: $" + cuotaMensual;
    }

    public void calcularPrestamo() {
        this.montoPagar = (this.montoPrestamo * this.interesAnual) + this.montoPrestamo;
        this.cuotaMensual = this.montoPagar / tiempoPago;
    }
    public void calcularInteresAnual(int tiempoDePago, double montoAPagar){
        if(tiempoDePago>=1 && tiempoDePago<=12){
            this.interesAnual = this.montoPagar*0.50;
        }else{
            if(tiempoDePago>=13 && tiempoDePago<=24){
                this.interesAnual = this.montoPagar * 0.45;
            }else{
                if(tiempoDePago>=25 && tiempoDePago<=36){
                    this.interesAnual=this.montoPagar*0.35;
                }else{
                    if(tiempoDePago>=37 && tiempoDePago<=48){
                        this.interesAnual = this.montoPagar*0.25;
                    }else{
                        if(tiempoDePago>=49 && tiempoDePago<=60){
                            this.interesAnual=this.montoPagar*0.20;
                        }else{
                            if(tiempoDePago>=61 && tiempoDePago<120){
                                this.interesAnual=this.montoPagar*0.15;
                            }else{
                                if(tiempoDePago>=120 && tiempoDePago<=180){
                                    this.interesAnual = this.montoPagar*0.12;
                                }else{
                                    if(tiempoDePago>180){
                                        this.interesAnual=this.montoPagar*0.10;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
    }

    public Prestamo(double montoPrestamo, int tiempoPago) {
        this.montoPrestamo = montoPrestamo;
        this.tiempoPago = tiempoPago;
    }
   
    public double getMontoPrestamo() {
        return montoPrestamo;
    }

    public void setMontoPrestamo(double montoPrestamo) {
        this.montoPrestamo = montoPrestamo;
    }

    public double getMontoPagar() {
        return montoPagar;
    }

    public void setMontoPagar(double montoPagar) {
        this.montoPagar = montoPagar;
    }

    public double getInteresAnual() {
        return interesAnual;
    }

    public void setInteresAnual(double interesAnual) {
        this.interesAnual = interesAnual;
    }

    public double getCuotaMensual() {
        return cuotaMensual;
    }

    public void setCuotaMensual(double cuotaMensual) {
        this.cuotaMensual = cuotaMensual;
    }

    public int getTiempoPago() {
        return tiempoPago;
    }

    public void setTiempoPago(int tiempoPago) {
        this.tiempoPago = tiempoPago;
    }

}